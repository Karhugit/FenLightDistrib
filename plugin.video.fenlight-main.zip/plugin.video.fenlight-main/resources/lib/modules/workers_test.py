import os
import time
import concurrent.futures

def task(n):
    # Simulate a mixed workload (CPU + I/O)
    time.sleep(1)  # I/O-bound
    result = sum(i * i for i in range(10000))  # CPU-bound
    return result

def find_optimum_max_workers():
    cpu_count = os.cpu_count()
    print(f"CPU cores: {cpu_count}")
    
    for workers in range(1, cpu_count * 4 + 1):
        start_time = time.time()
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            results = list(executor.map(task, range(20)))
        end_time = time.time()
        print(f"max_workers={workers}, Time taken: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    find_optimum_max_workers()